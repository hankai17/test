/*************************************************************************
	> File Name: main.cpp
	> Author: Bill
	> Mail: hankai17@126.com 
	> Created Time: 2017-01-19 17:37:21
 ************************************************************************/

#include<iostream>
#include "icr_icscheck.hpp"


int main()
{
	icscheck test;
	
	while(1);
	return 0;
}


